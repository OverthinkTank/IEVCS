package com.example.vwake.mylocation;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by vwake on 08-03-2018.
 */

public class HospitalLocation {

    public static ArrayList<LocationBean> getHospitalDetails(Double lat , Double lng){

        HttpsURLConnection httpURLConnection = null;

/*        try {
            SSLContext sslc = SSLContext.getInstance("TLS");
            sslc.init(null, new TrustManager[] { localTrustmanager },
                    new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sslc
                    .getSocketFactory());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }*/

        try {
            URL url = new URL("https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="+lat+","+lng+"&radius=4000&types=hospital&key=AIzaSyAmuZprw0ucM93b5U0UiqUAUr2A0PRhN2E");



            Log.i("loc",""+lat+" "+lng);
            Log.i("uri",url.toString());


            httpURLConnection= (HttpsURLConnection) url.openConnection();
//            httpURLConnection.setHostnameVerifier(DUMMY_VERIFIER);
            httpURLConnection.setRequestMethod("GET");

            Log.i("Info","Info1");


            httpURLConnection.setInstanceFollowRedirects(false);
            httpURLConnection.setReadTimeout(15000);
            httpURLConnection.setConnectTimeout(15000);



            httpURLConnection.connect();

            Map<String,List<String>> map = httpURLConnection.getHeaderFields();

            for (Map.Entry<String, List<String>> entry : map.entrySet()){
                String key = entry.getKey();
                List<String> value = entry.getValue();
                Log.i("Headers",key+"  "+value);

            }

            InputStream inputStream;
            StringBuilder sb = new StringBuilder();

            inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String temp = bufferedReader.readLine();
            while (temp != null){
                sb.append(temp);
                temp = bufferedReader.readLine();
            }

            Log.i("Data-Web",sb.toString());
            return getLocationData(sb.toString());



        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return new ArrayList<LocationBean>();
    }

    public static ArrayList<LocationBean> getLocationData(String jsonData){
        ArrayList<LocationBean> arrayList = new ArrayList<>();

        try {
            JSONObject jsonObject = new JSONObject(jsonData);
            JSONArray jsonArray = jsonObject.getJSONArray("results");
            for (Integer i = 0 ; i < jsonArray.length() ; i++){
                JSONObject locationData = (JSONObject) jsonArray.get(i);
                String location = locationData.getString("vicinity");
                locationData = locationData.getJSONObject("geometry");
                locationData = locationData.getJSONObject("location");
                Double lat = locationData.getDouble("lat");
                Double lng = locationData.getDouble("lng");
                arrayList.add(new LocationBean(location,lat,lng));

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return arrayList;
    }


}
