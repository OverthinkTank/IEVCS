package com.example.vwake.mylocation;

/**
 * Created by Yash on 11-03-2018.
 */

public class LocationBean {

    String name;
    Double lat;
    Double lgn;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocationBean(String name, Double lat, Double lgn) {
        this.name = name;
        this.lat = lat;
        this.lgn = lgn;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLgn() {
        return lgn;
    }

    public void setLgn(Double lgn) {
        this.lgn = lgn;
    }
}
