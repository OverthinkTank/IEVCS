package com.example.vwake.mylocation;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity   {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        if(Build.VERSION.SDK_INT>Build.VERSION_CODES.LOLLIPOP_MR1){

            if(! hasPermission("android.permission.WRITE_EXTERNAL_STORAGE")){
                String[] perms = {"android.permission.WRITE_EXTERNAL_STORAGE",
                        "android.permission.READ_EXTERNAL_STORAGE",
                        "android.permission.ACCESS_FINE_LOCATION"
                };

                requestPermissions(perms, 124);
            }

        }




        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);








        TextView textView = (TextView)  findViewById(R.id.share_location);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),LocationActivity.class));
            }
        });

        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add("Accident Fatal");
        arrayList.add("Accident Normal");
        arrayList.add("Cardiac Arrest");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getApplicationContext(),R.layout.simple_list , arrayList);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);

        spinner.setAdapter(arrayAdapter);


    }

    @Override
    public void onRequestPermissionsResult(int permsRequestCode, String[] permissions, int[] grantResults){



        switch(permsRequestCode){

            case 200:
                if(grantResults.length > 0) {
                    boolean writeAccepted = grantResults[0] == PackageManager.PERMISSION_GRANTED;
                }
                break;

        }

    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean hasPermission(String permission){

        return(checkSelfPermission(permission)==PackageManager.PERMISSION_GRANTED);


    }


}
