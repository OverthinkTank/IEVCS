package com.example.vwake.mylocation;

import android.content.AsyncTaskLoader;
import android.content.Context;

/**
 * Created by vwake on 08-03-2018.
 */

public class HospitalLocationLoader extends AsyncTaskLoader {
    private final Double lat;
    private final Double lgn;

    public HospitalLocationLoader(Context context , Double lat , Double lgn) {
        super(context);
        this.lat = lat;
        this.lgn = lgn;
    }


    @Override
    public Object loadInBackground() {
        return HospitalLocation.getHospitalDetails(lat,lgn);

    }
}

